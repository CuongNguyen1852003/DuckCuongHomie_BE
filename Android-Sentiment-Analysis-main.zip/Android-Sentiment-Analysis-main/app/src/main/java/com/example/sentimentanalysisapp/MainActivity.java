package com.example.sentimentanalysisapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.*;
import android.util.Log;

import org.json.JSONObject;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private EditText inputText;
    private Button submitButton;
    private ImageView sentimentIcon;
    private static final String API_KEY = "AIzaSyAIQnRNJevv7pCrA7KBkREdZ2jqp1nCjxI"; // Thay bằng API key thực tế
    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + API_KEY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText = findViewById(R.id.inputText);
        submitButton = findViewById(R.id.submitButton);
        sentimentIcon = findViewById(R.id.sentimentIcon);

        submitButton.setOnClickListener(v -> analyzeSentiment());
    }

    private void analyzeSentiment() {
        String text = inputText.getText().toString();
        if (text.isEmpty()) {
            Log.d("SentimentApp", "Input is empty");
            return;
        }

        OkHttpClient client = new OkHttpClient();
        String json = "{ \"contents\": [{ \"parts\": [{ \"text\": \"Classify this text as positive, negative, or neutral. Only return one word. Text: " + text + "\" }] }] }";

        RequestBody body = RequestBody.create(json, MediaType.get("application/json; charset=utf-8"));
        Request request = new Request.Builder()
                .url(API_URL)
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("SentimentApp", "API call failed: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    Log.e("SentimentApp", "API response failed: " + response.code() + " - " + response.message());
                    return;
                }

                String responseBody = response.body().string();
                Log.d("SentimentApp", "API Response: " + responseBody);

                try {
                    JSONObject jsonResponse = new JSONObject(responseBody);
                    if (!jsonResponse.has("candidates")) {
                        Log.e("SentimentApp", "No candidates in response");
                        return;
                    }

                    String sentiment = jsonResponse.getJSONArray("candidates")
                            .getJSONObject(0)
                            .getJSONObject("content")
                            .getJSONArray("parts")
                            .getJSONObject(0)
                            .getString("text")
                            .trim().toLowerCase();

                    if (!sentiment.equals("positive") && !sentiment.equals("negative") && !sentiment.equals("neutral")) {
                        sentiment = "neutral";
                    }

                    String finalSentiment = sentiment;
                    runOnUiThread(() -> updateUI(finalSentiment));

                } catch (Exception e) {
                    Log.e("SentimentApp", "Error parsing JSON: " + e.getMessage());
                }
            }
        });
    }




    private void updateUI(String sentiment) {
        int iconRes;
        if (sentiment.contains("positive")) {
            iconRes = R.drawable.ic_happy; // Thêm icon vui vào res/drawable
        } else if (sentiment.contains("negative")) {
            iconRes = R.drawable.ic_sad; // Thêm icon buồn vào res/drawable
        } else {
            iconRes = R.drawable.ic_neutral; // Thêm icon trung lập vào res/drawable
        }
        sentimentIcon.setImageResource(iconRes);
    }
}
